#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
b1=f.getvalue("b1")
try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  f=0
  for x in collection.find({}):
     if(x['Lid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record Already exist')</script>")
  else:
        insert1={'Lid':t1,'Lname':t2,'Ladd':t3}
        collection.insert_one(insert1)
        print("<script>alert('Record saved...')</script>")

 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  collection.update_many({'Lid':t1},{'$set':{'Lname':t2,'Ladd':t3}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  d={'Lid':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Location All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Location Id</th><th>Location  Name</th><th>Location Address</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['Lid'],"</th>")
    print("<th>",x['Lname'],"</th>")
    print("<th>",x['Ladd'],"</th></tr>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Location All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Location Id</th><th>Location  Name</th><th>Location Address</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['Lid'],"</th>")
    print("<th>",x['Lname'],"</th>")
    print("<th>",x['Ladd'],"</th></tr>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Location All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Location Id</th><th>Location  Name</th><th>Location Address</th></tr>")
  for x in collection.find({'Lid':t1}):
    print("<tr><th>",x['Lid'],"</th>")
    print("<th>",x['Lname'],"</th>")
    print("<th>",x['Ladd'],"</th></tr>")

 if(b1=="SpecialUpdate"):
  t1=f.getvalue("t1")
  t2=f.getvalue("t2")
  t3=f.getvalue("t3")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  print("<form name=f method=post action=Location.py>")
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Location All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Location Id</th><th>Location  Name</th><th>Location Address</th><th>Record Update</th></tr>")
  for x in collection.find({'Lid':t1}):
    print("<tr><th><input type=text value=",x['Lid'],"name=t1 readonly></th>")
    print("<th><input type=text value=",x['Lname'],"name=t2></th>")
    print("<th><input type=text value=",x['Ladd'],"name=t3></th>")
    print("<th><input type=submit value=Update name=b1></th></tr>")

 if(b1=="New"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Location']
  f=0
  for x in collection.find({}):
     if(x['Lid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record Already exist')</script>")
  else:
        print("<script>alert('Record not exist')</script>")
 
 
except Exception:
 traceback.print_exc()

