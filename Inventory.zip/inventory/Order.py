#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
b1=f.getvalue("b1")
try:

 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  f=0
  for x in collection.find({}):
     if(x['Oid']==t1):
       f=1
       break
  if(f==1):
   print("<script>alert('  Record Already exist')</script>")
  else:
   insert1={'Oid':t1,'Odate':t2}
   collection.insert_one(insert1)
   print("<script>alert('Record saved...')</script>") 

 if(b1=="New"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  f=0
  for x in collection.find({}):
     if(x['Oid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record Already exist')</script>")
  else:
        print("<script>alert('Record not exist')</script>")
 


 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  collection.update_many({'Oid':t1},{'$set':{'Odate':t2}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  d={'Oid':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Order Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>ID</th><th>Odate</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['Oid'],"<p></th>")
    print("<th>",x['Odate'],"</th></tr>")
 

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  print("<center><body bgcolor=#ED8A3F><p><h1>Order Data</h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>ID</th><th>Odate</th></tr>")
  for x in collection.find({'Oid':t1}):
    print("<tr><th>",x['Oid'],"</th>")
    print("<th>",x['Odate'],"</th></tr>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  t2=f.getvalue("t2")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  print("<center><body bgcolor=#ED8A3F><p><h1>Order Data</h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>ID</th><th>Odate</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['Oid'],"</th>")
    print("<th>",x['Odate'],"</th></tr>")

 if(b1=="SpecialUpdate"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Order']
  print("<form name=f method=post action=Order.py>")
  print("<center><body bgcolor=#ED8A3F><p><h1>Order Data</h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>ID</th><th>Odate</th><th>Record Update</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th><input type=text value=",x['Oid'],"name=t1 readonly></th>")
    print("<th><input type=text value=",x['Odate'],"name=t2></th>")
    print("<th><input type=submit value=update name=b1></th></tr>")
 
except Exception:
 traceback.print_exc()
