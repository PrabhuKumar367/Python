#!C:/Users/DELL/AppData/Local/Programs/Python/Python312/Python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
b1=f.getvalue("b1")
try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  f=0
  for x in collection.find({}):
     if(x['cid']==t1):
       f=1
       break
  if(f==1):
       print("<script>alert(' Record already exist')</script>")
  else:
     insert1={'cid':t1,'cname':t2,'cadd':t3}
     collection.insert_one(insert1)
     print("<script>alert('Record saved...')</script>")

 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  collection.update_many({'cid':t1},{'$set':{'cname':t2,'cadd':t3}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  d={'cid':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Customer All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Customer Id</th><th>Customer Name</th><th>Customer Address</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['cid'],"</th>")
    print("<th>",x['cname'],"</th>")
    print("<th>",x['cadd'],"</th></tr>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Customer All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Customer Id</th><th>Customer Name</th><th>Customer Address</th></tr>")
  for x in collection.find({'cid':t1}):
    print("<tr><th>",x['cid'],"</th>")
    print("<th>",x['cname'],"</th>")
    print("<th>",x['cadd'],"</th></tr>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Customer All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Customer Id</th><th>Customer Name</th><th>Customer Address</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['cid'],"</th>")
    print("<th>",x['cname'],"</th>")
    print("<th>",x['cadd'],"</th></tr>")

 if(b1=="SpecialUpdate"):
  t1=f.getvalue("t1")
  t2=f.getvalue("t2")
  t3=f.getvalue("t3")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  print("<form name=f method=post action=Customer.py>")
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Customer All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Customer Id</th><th>Customer Name</th><th>Customer Address</th><th>Record Update</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th><input type=text value=",x['cid'],"name=t1 readonly></th>")
    print("<th><input type=text value=",x['cname']," name=t2></th>")
    print("<th><input type=text value=",x['cadd'],"name=t3></th>")
    print("<th><input type=submit value=Update name=b1></th></tr>")

 if(b1=="New"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Customer']
  f=0
  for x in collection.find({}):
     if(x['cid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record already exist')</script>")
  else:
        print("<script>alert('Record  not exist')</script>")
 
 
except Exception:
 traceback.print_exc()
