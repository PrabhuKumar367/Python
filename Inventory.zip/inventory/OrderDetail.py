#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
t4=f.getvalue("t4")
b1=f.getvalue("b1")

try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  f=0
  for x in collection.find({}):
     if(x['id']==t1):
       f=1
       break
  if(f==1):
   print("<script>alert('  Record Already exist')</script>")
  else:
   insert1={'id':t1,'qty':t2,'adate1':t3,'rdate1':t4}
   collection.insert_one(insert1)
   print("<script>alert('Record saved...')</script>")


 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  collection.update_many({'id':t1},{'$set':{'qty':t2,'adate1':t3,'rdate1':t4}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  d={'id':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>OrderDetail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>OrderDetail Id</th><th>qty</th><th>adate</th><th>rdate</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['id'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['adate1'],"</th>")
    print("<th>",x['rdate1'],"</th></tr>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>OrderDetail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>OrderDetail Id</th><th>qty</th><th>adate</th><th>rdate</th></tr>")
 for x in collection.find({'id':t1}):
   print("<tr><th>",x['id'],"</th>")
   print("<th>",x['qty'],"</th>")
   print("<th>",x['adate1'],"</th>")
   print("<th>",x['rdate1'],"</th>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['OrderDetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>OrderDetail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>OrderDetail Id</th><th>qty</th><th>adate</th><th>rdate</th></tr>")
 for x in collection.find({s:t1}):
   print("<tr><th>",x['id'],"</th>")
   print("<th>",x['qty'],"</th>")
   print("<th>",x['adate1'],"</th>")
   print("<th>",x['rdate1'],"</th>")


except Exception:
 traceback.print_exc()
