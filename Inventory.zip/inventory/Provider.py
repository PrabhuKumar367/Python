#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
b1=f.getvalue("b1")
try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  f=0
  for x in collection.find({}):
     if(x['Pid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record ready exist')</script>")
  else:
       insert1={'Pid':t1,'Pname':t2,'Padd':t3}
       collection.insert_one(insert1)
       print("<script>alert('Record saved...')</script>")

 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  collection.update_many({'Pid':t1},{'$set':{'Pname':t2,'Padd':t3}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  d={'Pid':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Provider All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Provider Id</th><th>Provider Name</th><th>Provider Address</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['Pid'],"</th>")
    print("<th>",x['Pname'],"</th>")
    print("<th>",x['Padd'],"</th>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Provider All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Provider Id</th><th>Provider Name</th><th>Provider Address</th></tr>")
  for x in collection.find({'Pid':t1}):
    print("<tr><th>",x['Pid'],"</th>")
    print("<th>",x['Pname'],"</th>")
    print("<th>",x['Padd'],"</th>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Provider All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Provider Id</th><th>Provider Name</th><th>Provider Address</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['Pid'],"</th>")
    print("<th>",x['Pname'],"</th>")
    print("<th>",x['Padd'],"</th>")

 if(b1=="SpecialUpdate"):
  t1=f.getvalue("t1")
  t2=f.getvalue("t2")
  t3=f.getvalue("t3")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  print("<form name=f method=post action=Provider.py>")
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Provider All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Provider Id</th><th>Provider Name</th><th>Provider Address</th><th>Record Update</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th><input type=text value=",x['Pid'],"name=t1 readonly></th>")
    print("<th><input type=text value=",x['Pname'],"name=t2></th>")
    print("<th><input type=text value=",x['Padd'],"name=t3></th>")
    print("<th><input type=submit value=Update name=b1></th></tr>")

    


 if(b1=="New"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Provider']
  f=0
  for x in collection.find({}):
     if(x['Pid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record ready exist')</script>")
  else:
        print("<script>alert('Record not exist')</script>")
 
 
except Exception:
 traceback.print_exc()
