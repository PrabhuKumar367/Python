#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
t4=f.getvalue("t4")
b1=f.getvalue("b1")
try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  insert1={'did':t1,'qty':t2,'expdate':t3,'actdate':t4}
  collection.insert_one(insert1)
  print("<script>alert('Record saved...')</script>")

 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  collection.update_many({'did':t1},{'$set':{'qty':t2,'expdate':t3,'actdate':t4}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  d={'did':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Delivery Detail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Delivarydetail Id</th><th>qty</th><th>expdate</th><th>actdate</th></tr>")
  for x in collection.find({}):
    print("<tr><th>",x['did'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['expdate'],"</th>")
    print("<th>",x['actdate'],"</th></tr>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Delivery Detail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Delivarydetail Id</th><th>qty</th><th>expdate</th><th>actdate</th></tr>")
  for x in collection.find({'did':t1}):
    print("<tr><th>",x['did'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['expdate'],"</th>")
    print("<th>",x['actdate'],"</th></tr>")

 if(b1=="Specialsearch"):
  t1=f.getvalue("t1")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Delivery Detail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Delivarydetail Id</th><th>qty</th><th>expdate</th><th>actdate</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['did'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['expdate'],"</th>")
    print("<th>",x['actdate'],"</th></tr>")

 if(b1=="SpecialUpdate"):
  t1=f.getvalue("t1")
  t2=f.getvalue("t2")
  t3=f.getvalue("t3")
  t4=f.getvalue("t4")
  s=f.getvalue("s")
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Deliverydetail']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Delivery Detail All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Delivarydetail Id</th><th>qty</th><th>expdate</th><th>actdate</th></tr>")
  for x in collection.find({s:t1}):
    print("<tr><th>",x['did'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['expdate'],"</th>")
    print("<th>",x['actdate'],"</th></tr>")

except Exception:
 traceback.print_exc()
