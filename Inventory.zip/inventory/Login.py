#!C:/Users/DELL/AppData/Local/Programs/Python/Python312/Python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
b1=f.getvalue("b1")
try:
  if(b1=="Login"):
   client=pymongo.MongoClient("mongodb://localhost:27017/")
   db=client['inventory']
   collection=db['login']
   f=0
   for x in collection.find({}):
    if(x['id']==t1  and x['pwd']==t2):
      f=1
      break
   if(f==1):
    print("<script>window.open('Menu.html','_self')</script>")
   else:
    print("<script>alert('This is wrong or password')</script>")

  if(b1=="Register"):
   client=pymongo.MongoClient("mongodb://localhost:27017/")
   db=client['inventory']
   collection=db['login']
   f=0
   for x in collection.find({}):
     if(x['id']==t1):
       f=1
       break
   if(f==1):
       print("<script>alert(' This Id is  already Registed and  other Id try')</script>")
       print("<script>window.open('Register.html')</script>")
   else:
       insert1={'id':t1,'pwd':t2}
       collection.insert_one(insert1)
       print("<script>alert('Id successfully Registerted...')</script>")
except Exception:
 traceback.print_exc()
