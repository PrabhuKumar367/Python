#!C:/Users/Mantu/AppData/Local/Programs/Python/Python312/python
print("Content-Type:text/html")
print()
import cgi
import traceback
from pymongo import MongoClient
import pymongo
f=cgi.FieldStorage()
t1=f.getvalue("t1")
t2=f.getvalue("t2")
t3=f.getvalue("t3")
t4=f.getvalue("t4")
t5=f.getvalue("t5")
t6=f.getvalue("t6")
t7=f.getvalue("t7")
t8=f.getvalue("t8")
b1=f.getvalue("b1")
try:
 if(b1=="Save"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  insert1={'Pid':t1,'Pbarcode':t2,'Pname':t3,'desc':t4,'category':t5,'qty':t6,'weight':t7,'refrigerated':t8}
  collection.insert_one(insert1)
  print("<script>alert('Record saved...')</script>")

 if(b1=="Update"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  collection.update_many({'Pid':t1},{'$set':{'Pbarcode':t2,'Pname':t3,'desc':t4,'category':t5,'qty':t6,'weight':t7,'refrigerated':t8}})
  print("<script>alert('Record Updated....')</script>")


 if(b1=="Delete"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  d={'Pid':t1}
  collection.delete_many(d)
  print("<script>alert('Deleted....')</script>")

 if(b1=="Allsearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Product All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Product Id</th><th>Pbarcode</th><th>Pname</th><th>desc</th><th>category</th><th>qty</th><th>weight</th><th>refrigerated</th></tr>")
 for x in collection.find({}):
    print("<tr><th>",x['Pid'],"</th>")
    print("<th>",x['Pbarcode'],"</th>")
    print("<th>",x['Pname'],"</th>")
    print("<th>",x['desc'],"</th>")
    print("<th>",x['category'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['weight'],"</th>")
    print("<th>",x['refrigerated'],"</th>")

 if(b1=="Psearch"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  print("<center><body bgcolor=#ED8A3F><p><h1><u>Product All Data</u></h1> </p><table border=1 bgcolor=white bordercolor=black cellspacing=0   cellpadding=10><tr><th>Product Id</th><th>Pbarcode</th><th>Pname</th><th>desc</th><th>category</th><th>qty</th><th>weight</th><th>refrigerated</th></tr>")
  for x in collection.find({'Pid':t1}):
    print("<tr><th>",x['Pid'],"</th>")
    print("<th>",x['Pbarcode'],"</th>")
    print("<th>",x['Pname'],"</th>")
    print("<th>",x['desc'],"</th>")
    print("<th>",x['category'],"</th>")
    print("<th>",x['qty'],"</th>")
    print("<th>",x['weight'],"</th>")
    print("<th>",x['refrigerated'],"</th>")


 if(b1=="New"):
  client=pymongo.MongoClient("mongodb://localhost:27017/")
  db=client['inventory']
  collection=db['Product']
  f=0
  for x in collection.find({}):
     if(x['Pid']==t1):
       f=1
       break
  if(f==1):
        print("<script>alert(' Record already exist')</script>")
  else:
        print("<script>alert('Record  not exist')</script>")

except Exception:
 traceback.print_exc()
